"""Yuelly 集成的配置流。"""

from homeassistant import config_entries
from homeassistant.core import HomeAssistant, callback
from homeassistant.data_entry_flow import FlowResult
import voluptuous as vol

from .const import DOMAIN, LOGGER, DEFAULT_HOST, DEFAULT_PORT

# 我们可以定义一个空的数据模式，因为我们不需要用户输入
DATA_SCHEMA = vol.Schema({})


class YuellyConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    """Yuelly 的配置流程。"""

    VERSION = 1

    @staticmethod
    @callback
    def async_get_options_flow(config_entry):
        """返回选项流处理程序。"""
        # 如果将来需要通过 UI 修改 host/port，可以在这里添加 OptionsFlow
        return YuellyOptionsFlowHandler(config_entry)

    async def async_step_user(self, user_input: dict | None = None) -> FlowResult:
        """处理用户通过 UI 启动的配置步骤。"""

        # 检查是否已经配置过（可选，但推荐）
        await self.async_set_unique_id(DOMAIN)  # 使用DOMAIN作为唯一ID，确保只有一个实例
        self._abort_if_unique_id_configured()

        # 接收到输入 (user_input) 或首次启动时
        if user_input is not None or True:  # 我们总是立即成功
            # 使用默认值创建配置项
            data = {
                "host": DEFAULT_HOST,
                "port": DEFAULT_PORT,
            }

            LOGGER.debug(f"Creating config entry with default data: {data}")

            # 创建配置项并完成配置流
            return self.async_create_entry(title="Yuelly Cloud", data=data)

        # 虽然不会执行到这里，但保持结构完整性
        return self.async_show_form(step_id="user", data_schema=DATA_SCHEMA)


class YuellyOptionsFlowHandler(config_entries.OptionsFlow):
    """处理集成选项。"""

    def __init__(self, config_entry: config_entries.ConfigEntry):
        """初始化选项流。"""
        self.config_entry = config_entry

    async def async_step_init(self, user_input: dict | None = None) -> FlowResult:
        """管理选项流。"""
        # 因为我们不需要选项，这里直接返回一个空的成功
        return self.async_create_entry(
            title="Yuelly Cloud", data=self.config_entry.options
        )
